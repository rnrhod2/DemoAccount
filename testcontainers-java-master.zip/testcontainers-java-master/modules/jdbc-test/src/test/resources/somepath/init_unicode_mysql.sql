CREATE TABLE bar (
  foo varchar(255) character set utf8
);

INSERT INTO bar (foo) VALUES ('привет мир');
