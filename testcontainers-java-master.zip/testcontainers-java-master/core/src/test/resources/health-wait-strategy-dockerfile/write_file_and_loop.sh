#!/bin/ash

echo sleeping
sleep 2
echo writing file
touch /testfile

while true; do sleep 1; done
